#ifndef OLIMPIADE_H_INCLUDED
#define OLIMPIADE_H_INCLUDED

#include <iostream>
using namespace std;

struct dataLomba{
    string namaLomba;
    string tingkatanLomba;
    int angkatan;
    int kuota;
};

struct dataPeserta{
    string Nama;
    string NIM;
    int angkatanPeserta;
    string asalUniv;
    int score = 0;
    int peringkat = 0;
};

typedef dataLomba infotypeLomba;
typedef dataPeserta infotypePeserta;
typedef struct elementLomba *adr_lomba;
typedef struct elementPeserta *adr_peserta;

struct elementLomba{
    infotypeLomba info;
    adr_lomba next;
};

struct elementPeserta{
    infotypePeserta info;
    adr_lomba lomba;
    adr_peserta next;
};

struct listPeserta{
    adr_peserta first;
};

struct listLomba{
    adr_lomba first;
};

int selectMenu();
// SLL //
void createListPeserta(listPeserta &L1);
infotypePeserta dataPesertaBaru(string nama, string nim, int angkatan_peserta, string asal_univ);
adr_peserta newElementPeserta(infotypePeserta x);
void insertFirstPeserta(listPeserta &L1, adr_peserta p);
adr_peserta GetPeserta(listPeserta L1, string peserta);
void deleteFirststPeserta(listPeserta &L1, adr_peserta &p);
void deleteAfterPeserta(listPeserta &L1,adr_peserta prec, adr_peserta &p);
void deleteLastPeserta(listPeserta &L1, adr_peserta &p);
void showAllPeserta(listPeserta L1);
void showAllPesertadanAllLomba(listPeserta L1, listLomba L2); // terurut berdasarkan lomba //
void showTotalPeserta(listPeserta L1, listLomba L2, int Total);
// CSLL //
void createListLomba(listLomba &L2);
infotypeLomba dataLombaBaru(string lomba,string level,int angkatan,int kuota);
adr_lomba createElementLomba(infotypeLomba x);
void insertLastL(listLomba &L2, adr_lomba &p);
adr_lomba GetLomba(listLomba L2, string lomba, int angkatan, string tingkatan);
void deleteFirstLomba(listLomba &L2, adr_lomba &p);
void deleteAfterLomba(listLomba &L2,adr_lomba prec, adr_lomba &p);
void deleteLastLomba(listLomba &L2, adr_lomba &p);
void showAllLomba(listLomba L2);
void showAllPesertaDalamSebuahLomba(listPeserta L1, listLomba L2);
void showSatuPesertaLombaTertentu(listPeserta L1, listLomba L2);
 // logika //
 // pindah peserta ke lomba lain, musti dapatttt //
 // input elemen list dan sambung ke list lain // beres
 // delete suatu element pada list lomba //
 // delete suatu element pada list peserta //
// find lomba // beres
// find peserta // beres
void RegistrasiPeserta(listPeserta &L1, listLomba L2, int &Total);
void inputLomba(listLomba &L2);
void gantiLomba(listPeserta &L1, listLomba &L2);
void DeletePeserta(listPeserta &L1, listLomba L2, int &Total);
void DeleteLomba(listPeserta &L1, listLomba &L2);
#endif // OLIMPIADE_H_INCLUDED
