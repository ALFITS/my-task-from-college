#include "olimpiade.h"

int main(){
    listLomba L2;
    listPeserta L1;
    int Total = 0 ;
    int pilihan = 0;
    createListLomba(L2);
    createListPeserta(L1);
    pilihan = selectMenu();
    while (pilihan != 0){
        if (pilihan == 1){
            inputLomba(L2);
        }else if (pilihan == 2 ){
            showAllLomba(L2);
        }else if (pilihan == 3){
            RegistrasiPeserta(L1,L2,Total);
        }else if (pilihan == 4){
            showAllPeserta(L1);
        }else if (pilihan == 5){
            DeletePeserta(L1,L2,Total);
        }else if (pilihan == 6){
            DeleteLomba(L1,L2);
        }else if (pilihan == 7){
            gantiLomba(L1,L2);
        }else if (pilihan == 8){
            showSatuPesertaLombaTertentu(L1,L2);
        }else if (pilihan == 9){
            showAllPesertaDalamSebuahLomba(L1,L2);
        }else if (pilihan == 10){
            showTotalPeserta(L1,L2,Total);
        }else if (pilihan == 11){
            showAllPesertadanAllLomba(L1,L2);
        }else{
            cout << "Masukkan sesuai dengan ada yang di MENU" << endl;
            pilihan = selectMenu();
        }
        string tanya;
        cout << "Kembali ke menu utama (Y) atau Keluar Program (N) ? ";
        cin >> tanya;
        if(tanya=="Y"||tanya=="y")
        {
            cout << endl;
            pilihan = selectMenu();
        }
        else if (tanya=="N"||tanya=="n")
        {
            cout<<"Anda telah keluar dari program"<<endl;
            pilihan = 0;
        }
        else
        {
            cout << "Error" <<endl;
            cout << "Memaksa keluar dari program" << endl;
            cout<<"Anda telah keluar dari program"<<endl;
            pilihan = 0;
        }
    }
    return 0;
}
