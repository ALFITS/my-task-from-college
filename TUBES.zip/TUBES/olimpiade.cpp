#include "olimpiade.h"

int selectMenu(){
    cout << "=====================================TUBES OLIMPIADE=====================================" << endl;
    cout << "==========================================MENU===========================================" << endl;
    cout << "1.  Menambahkan N Lomba Baru" << endl;
    cout << "2.  Menampilkan Semua Lomba" << endl;
    cout << "3.  Memasukkan N Peserta" << endl;
    cout << "4.  Menampilkan Semua Peserta" << endl;
    cout << "5.  Menghapus 1 peserta" << endl;
    cout << "6.  Menghapus 1 Lomba" << endl;
    cout << "7.  Mengganti Lomba Suatu Peserta" << endl;
    cout << "8.  Menampilkan 1 Mahasiswa Mengikuti Lomba Tertentu" << endl;
    cout << "9.  Menampilkan Semua Mahasiswa Yang Mengikuti Lomba Tertentu" << endl;
    cout << "10. Menampilkan Total Peserta Yang Mengikuti Olimpiade" << endl;
    cout << "11. Menampilkan Semua Peserta Beserta Lombanya" << endl;
    cout << "0. Exit" << endl;
    cout << "Masukkan menu : ";
    int input = 0;
    cin >> input;
    cout << "=========================================================================================" << endl;
    cout << endl;
    return input;
}

// SLL //
void createListPeserta(listPeserta &L1){
   L1.first = NULL;
}

infotypePeserta dataPesertaBaru(string nama, string nim, int angkatan_peserta, string asal_univ){
    infotypePeserta PesertaBaru;
    PesertaBaru.Nama = nama;
    PesertaBaru.NIM = nim;
    PesertaBaru.angkatanPeserta = angkatan_peserta;
    PesertaBaru.asalUniv = asal_univ;
    return PesertaBaru;
}

adr_peserta newElementPeserta(infotypePeserta x){
    adr_peserta P = new elementPeserta;
    P -> info = x;
    P -> next = NULL;
    return P;
}

void insertFirstPeserta(listPeserta &L1, adr_peserta p){
    if(L1.first == NULL){
        L1.first = p;
    }else{
        p->next=L1.first;
        L1.first = p;
    }
}

adr_peserta GetPeserta(listPeserta L1, string peserta){
    adr_peserta q = L1.first;
    if (L1.first != NULL){
        while (q != NULL){
                if (q -> info.Nama == peserta){
                    return q;
                }
            q = q -> next;
        }
        cout << "Tidak Ada Peserta Yang Sesuai" << endl;
        cout << endl;
    }
    cout << "Tidak Ada Peserta" << endl;
    cout << endl;
    return NULL;
}

void deleteFirststPeserta(listPeserta &L1, adr_peserta &p){
    if(L1.first == NULL){
        cout << "List Kosong" << endl;
    }else if(L1.first -> next == NULL){
        p = L1.first;
        L1.first = NULL;
    }else{
         p = L1.first;
         L1.first = L1.first -> next;
         p -> next = NULL;
    }
}

void deleteAfterPeserta(listPeserta &L1, adr_peserta prec, adr_peserta &p){
    prec ->next = p ->next;
    p->next = NULL;
}

void deleteLastPeserta(listPeserta &L1, adr_peserta &p){
    if(L1.first == NULL){
        cout << "List Kosong" << endl;
    }else if(L1.first -> next == NULL){
        p = L1.first;
        L1.first = NULL;
    }else{
        adr_peserta x = L1.first;
        while(x -> next -> next != NULL){
            x = x -> next;
        }
         p = x -> next;
         x -> next = NULL;
    }
}

void showAllPeserta(listPeserta L1){
    adr_peserta p = L1.first;
    if(p == NULL){
        cout<<"Tidak Ada Data Peserta"<<endl;
        cout << endl;
    }else{
        while(p != NULL){
            cout << "Nama: " << p -> info.Nama << endl;
            cout << "NIM: " << p -> info.NIM << endl;
            cout << "Angkatan: " << p -> info.angkatanPeserta << endl;
            cout << "Asal Universitas: " << p -> info.asalUniv << endl;
            cout << endl;
            p = p -> next;
        }
    }
}

void showAllPesertadanAllLomba(listPeserta L1, listLomba L2){ // terurut berdasarkan lomba //
    if (L1.first != NULL && L2.first != NULL){
        adr_lomba xL = L2.first->next;
        adr_peserta xP = L1.first;
        cout << "Nama Lomba: " << L2.first -> info.namaLomba << " ";
        cout << "Angkatan: " << L2.first -> info.angkatan << " ";
        cout << "Tingkat Lomba: " << L2.first -> info.tingkatanLomba << endl;
        cout << "Berikut Nama Peserta Yang Mengikuti Lomba ini" << endl;
        while(xP != NULL){
            if(xP->lomba->info.namaLomba==L2.first->info.namaLomba && xP->lomba->info.angkatan==L2.first->info.angkatan && xP->lomba->info.tingkatanLomba==L2.first->info.tingkatanLomba){
                cout << xP->info.Nama << endl;
            }
            xP=xP->next;
        }
        cout << endl;
        xP=L1.first;
        while(xL != L2.first){
            cout << "Nama Lomba: " << xL -> info.namaLomba << " ";
            cout << "Angkatan: " << xL -> info.angkatan << " ";
            cout << "Tingkat Lomba: " << xL -> info.tingkatanLomba << endl;
            cout << "Berikut Nama Peserta Yang Mengikuti Lomba ini" << endl;
            while(xP != NULL){
                if(xP->lomba->info.namaLomba==xL->info.namaLomba && xP->lomba->info.angkatan==xL->info.angkatan && xP->lomba->info.tingkatanLomba==xL->info.tingkatanLomba){
                    cout << xP->info.Nama << endl;
                }
                xP=xP->next;
            }
            xP=L1.first;
            xL=xL->next;
            cout << endl;
        }
    }else{
        cout << "Tidak Ada Data" << endl;
        cout << endl;
    }
}

void showTotalPeserta(listPeserta L1, listLomba L2, int Total){
   if (L1.first != NULL && L2.first != NULL){
    cout << "Total Peserta Yang Mengikuti Olimpiade Kali Ini Adalah: " << Total << endl;
    cout << endl;
    }else{
        cout << "Belum Ada Peserta Yang Mendaftar" << endl;
        cout << endl;
    }
}

// CSLL //

void createListLomba(listLomba &L2){
    L2.first = NULL;
}

infotypeLomba dataLombaBaru(string lomba,string level, int angkatan,int kuota){
    infotypeLomba lombaBaru;
    lombaBaru.namaLomba = lomba;
    lombaBaru.angkatan = angkatan;
    lombaBaru.tingkatanLomba = level;
    lombaBaru.kuota = kuota;
    return lombaBaru;
}

adr_lomba createElementLomba(infotypeLomba x){
    adr_lomba p = new elementLomba;
    p -> info = x;
    p -> next = NULL;
    return p;
}

void insertLastL(listLomba &L2, adr_lomba &p){
    if(L2.first == NULL){
        L2.first = p;
        L2.first -> next = L2.first;
    }else{
        adr_lomba x = L2.first;
        while(x -> next != L2.first){
            x = x -> next;
        }
        x -> next=p;
        p -> next=L2.first;
    }
}

adr_lomba GetLomba(listLomba L2, string lomba, int angkatan, string tingkatan){
    adr_lomba q = L2.first;
    if (L2.first != NULL){
        while (q != NULL){
                if ((q -> info.namaLomba == lomba) && (q->info.tingkatanLomba == tingkatan) && (q->info.angkatan == angkatan)){
                    return q;
                }
            q = q -> next;
        }
        cout << "Tidak Ada Data Yang Sesuai" << endl;
        cout << endl;
    }
    cout << "Tidak Ada Data Yang Sesuai" << endl;
    cout << endl;
    return NULL;
}

void deleteFirstLomba(listLomba &L2, adr_lomba &p){
    if(L2.first == NULL){
        cout << "List Kosong" << endl;
    }else if(L2.first -> next == L2.first){
        p = L2.first;
        L2.first = NULL;
        p -> next = NULL;
    }else{
        adr_lomba x = L2.first;
        while(x -> next != L2.first){
            x = x -> next;
        }
         p = L2.first;
         L2.first = L2.first -> next;
         p -> next = NULL;
         x -> next = L2.first;
    }
}

void deleteAfterLomba(listLomba &L2,adr_lomba prec, adr_lomba &p){
    prec ->next = p ->next;
    p->next = NULL;
}

void deleteLastLomba(listLomba &L2, adr_lomba &p){
    if(L2.first == NULL){
        cout << "List Kosong" << endl;
    }else if(L2.first -> next == L2.first){
        p = L2.first;
        L2.first = NULL;
        p -> next = NULL;
    }else{
        adr_lomba x = L2.first;
        while(x -> next -> next != L2.first){
            x = x -> next;
        }
         p = x -> next;
         x -> next = L2.first;
         p -> next = NULL;
    }
}

void showAllLomba(listLomba L2){
    if(L2.first == NULL){
        cout << "Tidak Ada Lomba" << endl;
    }else{
        adr_lomba x = L2.first->next;
        cout << "Nama Lomba: " << L2.first -> info.namaLomba << endl;
        cout << "Untuk Angkatan: " << L2.first -> info.angkatan << endl;
        cout << "Tingkat Lomba: " << L2.first -> info.tingkatanLomba << endl;
        cout << "Kuota Lomba: " << L2.first -> info.kuota << endl;
        while(x != L2.first){
            cout << "Nama Lomba: " << x -> info.namaLomba << endl;
            cout << "Untuk Angkatan: " << x -> info.angkatan << endl;
            cout << "Tingkat Lomba: " << x -> info.tingkatanLomba << endl;
            cout << "Kuota Lomba: " << x -> info.kuota << endl;
            x = x -> next;
        }
    }
    cout << endl;
}

void showAllPesertaDalamSebuahLomba(listPeserta L1, listLomba L2){
    adr_lomba xL;
    adr_peserta xP = L1.first;
    string namalomba,tingkatan;
    int angkatan;
    int JumPeserta = 1;
    if (L1.first != NULL && L2.first != NULL){
        cout << "Masukkan Nama Lomba Yang Ingin Ditampilkan: ";
        cin >> namalomba;
        cout << "Angkatan: ";
        cin >> angkatan;
        cout << "Tingkat Lomba: ";
        cin >> tingkatan;
        xL = GetLomba(L2,namalomba,angkatan,tingkatan);
        cout << "Nama Lomba: " << xL -> info.namaLomba << " ";
        cout << "Untuk Angkatan: " << xL -> info.angkatan << " ";
        cout << "Tingkat Lomba: " << xL -> info.tingkatanLomba << endl;
        cout << "Berikut Peserta Yang Mengikuti Lomba ini" << endl;
        while(xP != NULL){
            if(xP->lomba->info.namaLomba==xL->info.namaLomba && xP->lomba->info.angkatan == xL->info.angkatan && xP->lomba->info.tingkatanLomba == xL->info.tingkatanLomba){
                cout << JumPeserta << ". ";
                cout << xP->info.Nama << endl;
                JumPeserta++;
            }
            xP=xP->next;
        }
        cout << "Total Peserta Yang Mengikuti Lomba " << namalomba << " Adalah " << JumPeserta-1 << " Peserta" << endl;
        cout<<endl;
    }else{
        cout << "Tidak Ada Data" << endl;
        cout << endl;
    }
}

void showSatuPesertaLombaTertentu(listPeserta L1, listLomba L2){
    string namaPeserta;
    if (L1.first != NULL && L2.first != NULL){
        cout << "Masukkan Nama Peserta Yang Ingin Ditampilkan: ";
        cin >> namaPeserta;
        adr_peserta peserta = GetPeserta(L1,namaPeserta);
        cout << "Nama Peserta: " << peserta->info.Nama << ", Mengikuti Lomba: " << peserta->lomba->info.namaLomba << ", Dengan Tingkat: " << peserta ->lomba -> info.tingkatanLomba << endl;
        cout << endl;
    }else{
        cout << "Tidak Ada Data" << endl;
        cout << endl;
    }
}

// logika //

void RegistrasiPeserta(listPeserta &L1, listLomba L2, int &Total){
    adr_peserta Peserta;
    adr_lomba Lomba;
    infotypePeserta newData;
    string Nama,  NIM, asalUniv, namalomba, levellomba;
    int n, angkatanPeserta;
    int check;
    int i = 0;
    cout << "Jumlah Peserta Yang Akan Ditambahkan : ";
    cin >> n;
    cout<<endl;
    while(i < n){
        cout << "Nama Peserta: ";
        cin >> Nama;
        cout << "NIM: ";
        cin >> NIM;
        cout << "Angkatan: ";
        cin >> angkatanPeserta;
        cout << "Asal Universitas: ";
        cin >> asalUniv;
        cout << "Mengikuti Lomba: ";
        cin >> namalomba;
        cout << "Tingkatan Lomba: ";
        cin >> levellomba;
        cout << endl;
        check = 0;
        newData = dataPesertaBaru(Nama,NIM,angkatanPeserta,asalUniv);
        Peserta = newElementPeserta(newData);
        Lomba = GetLomba(L2,namalomba,angkatanPeserta,levellomba);
        while (check != 1){
            if ((Lomba ->info.angkatan == Peserta ->info.angkatanPeserta) && (Lomba->info.kuota > 0) && (Lomba->info.tingkatanLomba == levellomba)){
                insertFirstPeserta(L1,Peserta);
                Peserta -> lomba = Lomba;
                Lomba ->info.kuota--;
                Total++;
                check = 1;
            }else if ((Lomba ->info.angkatan == Peserta ->info.angkatanPeserta) && (Lomba->info.kuota == 0) && (Lomba->info.tingkatanLomba == levellomba)){
                cout << "Kuota Lomba Tersebut Sudah Terpenuhi" << endl;
                cout << "Silahkan Pilih Lomba Yang Ada: ";
                cin >> namalomba;
                cout << "Tingkatan Lomba: ";
                cin >> levellomba;
                cout << "Angkatan: ";
                cin >> angkatanPeserta;
                Peserta->info.angkatanPeserta = angkatanPeserta;
                cout << endl;
                Lomba = GetLomba(L2,namalomba,angkatanPeserta,levellomba);
                check = 2;
            }else if ((Lomba ->info.angkatan == Peserta ->info.angkatanPeserta) && (Lomba->info.kuota != 0) && (Lomba->info.tingkatanLomba != levellomba)){
                cout << "Tidak Ada Kuota Untuk Angkatan Anda Pada Lomba Tersebut" << endl;
                cout << "Silahkan Pilih Lomba Yang Ada: ";
                cin >> namalomba;
                cout << "Tingkatan Lomba: ";
                cin >> levellomba;
                cout << "Angkatan: ";
                cin >> angkatanPeserta;
                Peserta->info.angkatanPeserta = angkatanPeserta;
                cout << endl;
                Lomba = GetLomba(L2,namalomba,angkatanPeserta,levellomba);
                check = 3;
            }else if ((Lomba ->info.angkatan != Peserta ->info.angkatanPeserta) && (Lomba->info.kuota != 0) && (Lomba->info.tingkatanLomba == levellomba)){
                cout << "Tidak Ada Kuota Untuk Level Anda Pada Lomba Tersebut" << endl;
                cout << "Silahkan Pilih Lomba Yang Ada: ";
                cin >> namalomba;
                cout << "Tingkatan Lomba: ";
                cin >> levellomba;
                cout << "Angkatan: ";
                cin >> angkatanPeserta;
                Peserta->info.angkatanPeserta = angkatanPeserta;
                cout << endl;
                Lomba = GetLomba(L2,namalomba,angkatanPeserta,levellomba);
                check = 4;
            }else{
                cout << "Tidak Ada Lomba Yang Sesuai" << endl;
                cout << "Silahkan Pilih Lomba Yang Ada: ";
                cin >> namalomba;
                cout << "Tingkatan Lomba: ";
                cin >> levellomba;
                cout << "Angkatan: ";
                cin >> angkatanPeserta;
                Peserta->info.angkatanPeserta = angkatanPeserta;
                cout << endl;
                Lomba = GetLomba(L2,namalomba,angkatanPeserta,levellomba);
                check = 5;
            }
        }
        i++;
        }

}

void inputLomba(listLomba &L2){
    adr_lomba datlom;
    infotypeLomba newData;
    string namaLomba, tingkatanLomba;
    int kuota, angkatan;
    int i = 0;
    int n;
    cout << "Jumlah Lomba yang akan ditambahkan: ";
    cin >> n;
    cout<<endl;
    while(i < n){
        cout << "Nama Lomba: ";
        cin >> namaLomba;
        cout << "Tingkatan Lomba: ";
        cin >> tingkatanLomba;
        cout << "Untuk Angkatan: ";
        cin >> angkatan;
        cout << "Kuota Lomba: ";
        cin >> kuota;
        cout << endl;
        newData = dataLombaBaru(namaLomba,tingkatanLomba,angkatan,kuota);
        datlom = createElementLomba(newData);
        insertLastL(L2,datlom);
        i++;
        }
}

void gantiLomba(listPeserta &L1, listLomba &L2){
    adr_lomba newlomba;
    adr_peserta PesertaGanti;
    string lombabaru, peserta, lvl, namalomba;
    int check = 0;
    cout << "Nama Peserta: ";
    cin >> peserta;
    cout << "Pindah Lomba ke Lomba: ";
    cin >> lombabaru;
    cout << "Dengan Tingkatan: ";
    cin >> lvl;
    PesertaGanti = GetPeserta(L1,peserta);
    newlomba = GetLomba(L2,lombabaru,PesertaGanti->info.angkatanPeserta,lvl);
    PesertaGanti->lomba ->info.kuota++;
    PesertaGanti -> lomba = NULL;
    while (check != 1){
        if ((newlomba ->info.angkatan == PesertaGanti ->info.angkatanPeserta) && (newlomba->info.kuota > 0) && (newlomba->info.tingkatanLomba == lvl)){
            PesertaGanti -> lomba = newlomba;
            newlomba ->info.kuota--;
            cout<<endl;
            check = 1;
        }else if ((newlomba ->info.angkatan == PesertaGanti ->info.angkatanPeserta) && (newlomba->info.kuota == 0) && (newlomba->info.tingkatanLomba == lvl)){
            cout << "Kuota Lomba Tersebut Sudah Terpenuhi" << endl;
            cout << "Silahkan Pilih Lomba Yang Ada: ";
            cin >> namalomba;
            cout << "Dengan Tingkatan: ";
            cin >> lvl;
            cout << endl;
            newlomba = GetLomba(L2,namalomba,PesertaGanti->info.angkatanPeserta,lvl);
            check = 0;
        }else if ((newlomba ->info.angkatan == PesertaGanti ->info.angkatanPeserta) && (newlomba->info.kuota != 0) && (newlomba->info.tingkatanLomba != lvl)){
            cout << "Tidak Ada Kuota Untuk Angkatan Anda Pada Lomba Tersebut" << endl;
            cout << "Silahkan Pilih Lomba Yang Ada: ";
            cin >> namalomba;
            cout << "Dengan Tingkatan: ";
            cin >> lvl;
            cout << endl;
            newlomba = GetLomba(L2,namalomba,PesertaGanti->info.angkatanPeserta,lvl);
            check = 0;
        }else if ((newlomba ->info.angkatan != PesertaGanti ->info.angkatanPeserta) && (newlomba->info.kuota != 0) && (newlomba->info.tingkatanLomba == lvl)){
            cout << "Tidak Ada Kuota Untuk Level Anda Pada Lomba Tersebut" << endl;
            cout << "Silahkan Pilih Lomba Yang Ada: ";
            cin >> namalomba;
            cout << "Dengan Tingkatan: ";
            cin >> lvl;
            cout << endl;
            newlomba = GetLomba(L2,namalomba,PesertaGanti->info.angkatanPeserta,lvl);
            check = 0;
        }else{
            cout << "Tidak Ada Lomba Yang Sesuai" << endl;
            cout << "Silahkan Pilih Lomba Yang Ada: ";
            cin >> namalomba;
            cout << "Dengan Tingkatan: ";
            cin >> lvl;
            cout << endl;
            newlomba = GetLomba(L2,namalomba,PesertaGanti->info.angkatanPeserta,lvl);
            check = 0;
        }
    }
    cout<<"Penggantian Lomba Berhasil"<<endl;
    cout<<endl;
}

void DeletePeserta(listPeserta &L1, listLomba L2, int &Total){
    string namaPeserta;
    adr_peserta X = L1.first;
    adr_peserta Q,p;

    if (L1.first != NULL){
    cout << "Masukkan Nama Peserta Yang Ingin Dihapus: ";
    cin >> namaPeserta;
    if (namaPeserta == L1.first ->info.Nama){
        L1.first -> lomba = NULL;
        deleteFirststPeserta(L1,p);
    }else if (namaPeserta == X ->info.Nama){
        while (X -> next != NULL){
            X = X ->next;
        }
        X -> lomba = NULL;
        deleteLastPeserta(L1,p);
    }else{
        Q = GetPeserta(L1,namaPeserta);
        while (X -> next != Q){
            X = X -> next;
        }
        Q -> lomba = NULL;
        deleteAfterPeserta(L1,X,p);
    }
    Total--;
    }else{
        cout << "Belum Ada Peserta Yang Di input" << endl;
        cout << endl;
    }
}

void DeleteLomba(listPeserta &L1, listLomba &L2){
    string namalomba,tingkatan;
    int angkatan;
    adr_peserta X = L1.first;
    adr_peserta Z = L1.first;
    adr_lomba Y = L2.first;
    adr_lomba Q,p;

    if (L2.first != NULL){
        cout << "Masukkan Nama Lomba Yang Ingin Dihapus: ";
        cin >> namalomba;
        cout << "Tingkatan Lomba Yang Ingin Dihapus: ";
        cin >> tingkatan;
        cout << "Angkatan Lomba Yang Ingin Dihapus: ";
        cin >> angkatan;
        while (Z ->next != NULL){
            Z = Z -> next;
        }
        if ((namalomba == L2.first ->info.namaLomba) && (tingkatan == L2.first ->info.tingkatanLomba) && (angkatan == L2.first->info.angkatan)){
            while (X  != NULL){
                if (X->lomba->info.namaLomba == namalomba && X->lomba->info.angkatan == angkatan && X->lomba->info.tingkatanLomba == tingkatan){
                        cout << "Peserta " << X->info.Nama << " Harus Mengganti lombanya" << endl;
                        gantiLomba(L1,L2);
                }
                X = X ->next;
            }
            deleteFirstLomba(L2,p);
        }else if ((namalomba == Z ->lomba->info.namaLomba) && (tingkatan == Z ->lomba->info.tingkatanLomba) && (angkatan == Z->lomba->info.angkatan)){
            while (X != NULL){
                if (X->lomba->info.namaLomba == namalomba && X->lomba->info.angkatan == angkatan && X->lomba->info.tingkatanLomba == tingkatan){
                        cout << "Peserta " << X->info.Nama << " Harus Mengganti lombanya" << endl;
                        gantiLomba(L1,L2);
                    }
                X = X ->next;
            }
            deleteLastLomba(L2,p);
        }else{
            while (X != NULL){
                if (X->lomba->info.namaLomba == namalomba && X->lomba->info.angkatan == angkatan && X->lomba->info.tingkatanLomba == tingkatan){
                    cout << "Peserta " << X->info.Nama << " Harus Mengganti lombanya" << endl;
                    gantiLomba(L1,L2);
                }
                X = X ->next;
            }
            Q = GetLomba(L2,namalomba,angkatan,tingkatan);
            while (Y -> next != Q){
                Y = Y -> next;
            }
            deleteAfterLomba(L2,Y,p);
        }
    }else{
        cout << "Belum Ada Lomba Yang Di input" << endl;
        cout << endl;
    }
}
